#include<QFile>
#include<QTextStream>
#include <QApplication>
#include<QGraphicsView>
#include"menu.h"
#include<QGraphicsPixmapItem>
#include<QGraphicsScene>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    Menu m;
    m.show();

    return a.exec();
}
