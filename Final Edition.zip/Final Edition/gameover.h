#ifndef GAMEOVER_H
#define GAMEOVER_H
#include <QDialog>
#include<QGraphicsView>
#include"level.h"
namespace Ui {
class GameOver;
}

class GameOver : public QDialog
{
    Q_OBJECT

public:
    explicit GameOver(QWidget *parent = nullptr, QGraphicsView* v=nullptr);
    void setstat(int x, int g, int p);
    ~GameOver();
    bool cont;
    bool getcont();
    QGraphicsView* gview;
    Level*inlevel;
    void setlevel(Level* l1);
    void setcont();
    void setview(QGraphicsView* v);

private slots:
    void on_exit_clicked();

    void on_continue_2_clicked();

private:
    Ui::GameOver *ui;
    int gems;
};

#endif // GAMEOVER_H
