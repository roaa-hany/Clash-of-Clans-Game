#ifndef POWERUP_H
#define POWERUP_H
#include<QGraphicsPixmapItem>

class powerup: public QObject, public QGraphicsPixmapItem
{
    Q_OBJECT
public:
    powerup();
};

#endif // POWERUP_H
