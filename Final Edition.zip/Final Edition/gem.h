#ifndef GEM_H
#define GEM_H
#include<QGraphicsPixmapItem>

class gem: public QObject, public QGraphicsPixmapItem
{
    Q_OBJECT
public:
    gem();
    //QGraphicsScene* scene;
};

#endif // GEM_H
